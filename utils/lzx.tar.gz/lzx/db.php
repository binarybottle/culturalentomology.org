<?php
//----------------------------
// Edit this section
//----------------------------
	$host     = "localhost";	// mysql host server
	$db       = "taxonomy";		// database name
	$username = "taxonomer";	// mysql db - user
	$password = "taxonomizes";	// mysql db - password
	
//----------------------------
// connecting mysql db
//----------------------------	
	$dbh = mysql_connect( $host, $username, $password );
	
	if ( !$dbh ){
	   $err=mysql_error(  );
	   die( "Database error: $err" );
	}
	else {
		mysql_select_db( $db, $dbh ) or die ( "Database not available!" );
	}
	
?>
