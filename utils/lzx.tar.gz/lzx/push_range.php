<?php

// Update image data in MySQL database
//
//``````````````````````````````````````````````````````````````````````````````
// (c) 2006, @rno klein
//
// This file is part of Classify.
//
// Classify is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// Classify is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public
// License along with Classify; if not, write to the
// Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//``````````````````````````````````````````````````````````````````````````````

   $img_limit = $_GET['image_limit'];
   $img_min   = $_GET['image_min'];
   $img_max   = $_GET['image_max'];

   $query  = 'UPDATE range SET ';
   $query .= "image_limit = '" . $img_limit . "', ";
   $query .= "image_min = '"   . $img_min   . "', ";
   $query .= "image_max = '"   . $img_max   . "'";

 // Log into MySQL server
    require_once('db.php');
    $result = mysql_query( $query, $dbh );
    echo "<result>" . ( $result ? "success" : "failure" ) . "</result>";
    mysql_close($dbh) or die ("Could not close connection to database!");
    
    //echo $query;