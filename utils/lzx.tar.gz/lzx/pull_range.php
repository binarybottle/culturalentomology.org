<?php

// Get image data from MySQL database
//
//``````````````````````````````````````````````````````````````````````````````
// (c) 2006, @rno klein
//
// This file is part of Classify.
//
// Classify is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// Classify is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public
// License along with Classify; if not, write to the
// Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//``````````````````````````````````````````````````````````````````````````````

 // Log into MySQL server
    require_once('db.php');

    $query = "SELECT * FROM range";
    $result = mysql_query($query,$dbh);
    
    if ($result) {
	
        $row = mysql_fetch_array($result, MYSQL_ASSOC);
	
        $image_limit = $row['image_limit'];
        $image_min   = $row['image_min'];
        $image_max   = $row['image_max'];

        $_xml  = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\r\n";
        $_xml .= "<images>\r\n";
		
     // Build XML string
        $_xml .= "\t<image image_limit='" . $image_limit . "'" . 
                         " image_min='"   . $image_min   . "'" . 
                         " image_max='"   . $image_max   . "'" . 
                         "/>\r\n";		
    }

    $_xml .= "</images>\r\n";

    echo $_xml;

    mysql_free_result($result);
    mysql_close($dbh) or die ("Could not close connection to database!");



		
