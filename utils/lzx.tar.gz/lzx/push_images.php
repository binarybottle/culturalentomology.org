<?php

// Update image data in MySQL database
//
//``````````````````````````````````````````````````````````````````````````````
// (c) 2006, @rno klein
//
// This file is part of Classify.
//
// Classify is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// Classify is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public
// License along with Classify; if not, write to the
// Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//``````````````````````````````````````````````````````````````````````````````

    if ( isset( $_GET['action'] ) )
    {   
        $action               = $_GET["action"];
        $pk                   = $_GET["pk"];
        $image_title          = $_GET["image_title"];
        $image_file           = $_GET["image_file"];
        $image_collection     = $_GET["image_collection"];
        $image_creator        = $_GET["image_creator"];
        $image_medium         = $_GET["image_medium"];
        $image_notes          = $_GET["image_notes"];
        $image_date           = $_GET["image_date"];
        $image_date2          = $_GET["image_date2"];
        $image_date_circa     = $_GET["image_date_circa"];
        $image_indate         = $_GET["image_indate"];
        $image_update         = $_GET["image_update"];
        $image_hide           = $_GET["image_hide"];
        $image_email          = $_GET["image_email"];
        $image_collection_url = $_GET["image_collection_url"];
        $image_url            = $_GET["image_url"];

     // Replace apostrophes with &#39; and quotes with &#34; (for use with OpenLaszlo);	
        $replace_marks=0;
        if ($replace_marks==1) {
           $image_title      = str_replace( "'",  "&#39;",    $image_title );
           $image_collection = str_replace( "'",  "&#39;",    $image_collection );
           $image_creator    = str_replace( "'",  "&#39;",    $image_creator );
           $image_medium     = str_replace( "'",  "&#39;",    $image_medium );
           $image_notes      = str_replace( "'",  "&#39;",    $image_notes );
           $image_title      = str_replace( "`",  "&#39;",    $image_title );
           $image_collection = str_replace( "`",  "&#39;",    $image_collection );
           $image_creator    = str_replace( "`",  "&#39;",    $image_creator );
           $image_medium     = str_replace( "`",  "&#39;",    $image_medium );
           $image_notes      = str_replace( "`",  "&#39;",    $image_notes );
           $image_title      = str_replace( "``", "&#34;",    $image_title );
           $image_collection = str_replace( "``", "&#34;",    $image_collection );
           $image_creator    = str_replace( "``", "&#34;",    $image_creator );
           $image_medium     = str_replace( "``", "&#34;",    $image_medium );
           $image_notes      = str_replace( "``", "&#34;",    $image_notes );
        }

        if ($action == "update") {
 
            $query  = "UPDATE images SET ";

            $query .= "image_title = '"          . $image_title          . "', ";
            $query .= "image_file = '"           . $image_file           . "', ";
            $query .= "image_collection = '"     . $image_collection     . "', ";
            $query .= "image_creator = '"        . $image_creator        . "', ";
            $query .= "image_medium = '"         . $image_medium         . "', ";
            $query .= "image_notes = '"          . $image_notes          . "', ";
            $query .= "image_date = '"           . $image_date           . "', ";
            $query .= "image_date2 = '"          . $image_date2          . "', ";
            $query .= "image_date_circa = '"     . $image_date_circa     . "', ";
            $query .= "image_indate = '"         . $image_indate         . "', ";
            $query .= "image_update = '"         . $image_update         . "', ";
            $query .= "image_hide = '"           . $image_hide           . "', ";
            $query .= "image_email = '"          . $image_email          . "', ";
            $query .= "image_collection_url = '" . $image_collection_url . "', ";
            $query .= "image_url = '"            . $image_url            . "' ";

            $query .= " WHERE image_ID = '"      . $pk                   . "' ";

        }

     // Log into MySQL server
        require_once('db.php');
        $result = mysql_query( $query, $dbh );
        echo "<result>" . ( $result ? "success" : "failure" ) . "</result>";
        
        mysql_free_result($result);
        mysql_close($dbh) or die ("Could not close connection to database!");
    }          


//  echo $query;