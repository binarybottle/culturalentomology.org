<?php

// Get image data from MySQL database
//
//``````````````````````````````````````````````````````````````````````````````
// (c) 2006, @rno klein
//
// This file is part of Classify.
//
// Classify is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// Classify is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty
// of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public
// License along with Classify; if not, write to the
// Free Software Foundation, Inc.,
// 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//``````````````````````````````````````````````````````````````````````````````

 // Log into MySQL server
    require_once('db.php');

 // Image repository
    $image_repository = "../taxonomy_images/";

    $query = "SELECT * FROM range";
    $result = mysql_query($query,$dbh);
    
    if ($result) {
	
        $row = mysql_fetch_array($result, MYSQL_ASSOC);
	
        $image_limit = $row['image_limit'];
        $image_min   = $row['image_min'];
        $image_max   = $row['image_max'];

        if ($image_limit > 0) {
            $query = "SELECT * FROM images WHERE image_hide=0 ORDER BY image_ID LIMIT 0, " . $image_limit;
        }
        else {
            $query = "SELECT * FROM images WHERE image_hide=0 AND image_ID>=" . $image_min . " AND image_ID<=" .  $image_max;
	}

        $result2 = mysql_query($query,$dbh);

        $_xml  = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\r\n";
        $_xml .= "<images>\r\n";
		
        if ($result2) {
		
            while ($row = mysql_fetch_array($result2, MYSQL_ASSOC)) {
			
	     // Extract each field, escape special characters	
                $image_ID             = $row['image_ID'];
                $image_title          = $row['image_title'];
                $image_file           = $row['image_file'];
                $image_collection     = $row['image_collection'];
                $image_creator        = $row['image_creator']; 
                $image_medium         = $row['image_medium']; 
                $image_notes          = $row['image_notes']; 
                $image_date           = $row['image_date'];
                $image_date2          = $row['image_date2'];
                $image_date_circa     = $row['image_date_circa'];
                $image_indate         = $row['image_indate'];
                $image_update         = $row['image_update'];
                $image_hide           = $row['image_hide'];
                $image_email          = $row['image_email'];
                $image_collection_url = $row['image_collection_url'];
                $image_url            = $row['image_url'];
                	       
                if ($image_file !='') { $image_file_full = $image_repository . $image_file; }
                else { $image_file_full = ''; }
	
             // Replace apostrophes with &#39; and quotes with &#34;(for use with OpenLaszlo);	
                $image_title      = str_replace( "'",  "&#39;", $image_title );
                $image_collection = str_replace( "'",  "&#39;", $image_collection );
                $image_creator    = str_replace( "'",  "&#39;", $image_creator );
                $image_medium     = str_replace( "'",  "&#39;", $image_medium );
                $image_notes      = str_replace( "'",  "&#39;", $image_notes );
                $image_title      = str_replace( "`",  "&#39;", $image_title );
                $image_collection = str_replace( "`",  "&#39;", $image_collection );
                $image_creator    = str_replace( "`",  "&#39;", $image_creator );
                $image_medium     = str_replace( "`",  "&#39;", $image_medium );
                $image_notes      = str_replace( "`",  "&#39;", $image_notes );
                $image_title      = str_replace( "``", "&#34;", $image_title );
                $image_collection = str_replace( "``", "&#34;", $image_collection );
                $image_creator    = str_replace( "``", "&#34;", $image_creator );
                $image_medium     = str_replace( "``", "&#34;", $image_medium );
                $image_notes      = str_replace( "``", "&#34;", $image_notes );


             // Build XML string
                $_xml .= "\t<image image_ID='" . $image_ID . "'" . 
                      " image_class_bottomup='" . $image_class_bottomup . "'" . 
                      " image_class_topdown='" . $image_class_topdown . "'" . 
                      " image_title='" . $image_title . "'" . 
                      " image_file='" . $image_file . "'" . 
                      " image_collection='" . $image_collection . "'" . 
                      " image_creator='" . $image_creator . "'" . 
                      " image_medium='" . $image_medium . "'" . 
                      " image_notes='" . $image_notes . "'" . 
                      " image_date='" . $image_date . "'" .  
                      " image_date2='" . $image_date2 . "'" .  
                      " image_date_circa='" . $image_date_circa . "'" . 
                      " image_indate='" . $image_indate . "'" . 
                      " image_update='" . $image_update . "'" . 
                      " image_hide='" . $image_hide . "'" . 
                      " image_email='" . $image_email . "'" . 
                      " image_collection_url='" . $image_collection_url . "'" . 
                      " image_url='" . $image_url . "'" . 
                      " image_file_full='" . $image_file_full . "'" . 
                      "/>\r\n";		
            }
            mysql_free_result($result2);
        }
    }

    $_xml .= "</images>\r\n";

    echo $_xml;

    mysql_free_result($result);
    mysql_close($dbh) or die ("Could not close connection to database!");
